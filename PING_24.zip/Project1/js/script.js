	// create the module and name it scotchApp
	var scotchApp = angular.module('scotchApp', ['ngRoute']);

	// configure our routes
	scotchApp.config(function($routeProvider) {
		$routeProvider

			// route for the home page
			.when('/', {
				templateUrl : 'pages/home.html',
				controller  : 'mainController'
			})
			
			
			.when('/home', {
				templateUrl : 'pages/home.html',
				controller  : 'mainController'
			})

			.when('/connexion', {
				templateUrl : 'pages/connexion.html',
				controller  : 'connexionController'
			})

			.when('/inscription', {
				templateUrl : 'pages/inscription.html',
				controller  : 'inscriptionController'
			})
			// route for the about page
			.when('/devis', {
				templateUrl : 'pages/devis.html',
				controller  : 'devisController'
			})

			// route for the contact page
			.when('/contact', {
				templateUrl : 'pages/contact.html',
				controller  : 'contactController'
			});
	});

	// create the controller and inject Angular's $scope
	scotchApp.controller('mainController', function($scope) {
		// create a message to display in our view
		$scope.message = 'Nous allons changer votre vie!';

		
	});
	
	
		scotchApp.controller('connexionController', function($scope) {
		$scope.message = 'veuillez vous connecter svp...';
	});


	

	scotchApp.controller('inscriptionController', function($scope) {
		$scope.message = 'veuillez vous inscrire svp...';
	});

	scotchApp.controller('devisController', function($scope) {
		$scope.message = 'JB AU TRAVAIL.';
	});

	scotchApp.controller('contactController', function($scope) {
		$scope.message = 'Contact us! JK. This is just a demo.';
	});
	
	


	
	
	